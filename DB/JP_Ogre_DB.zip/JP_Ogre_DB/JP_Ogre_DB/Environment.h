#ifndef _ENVIRONMENT_H
#define _EVINRONMENT_H

#include <windows.h>
#include <sql.h>
#include <sqlext.h>

class Environment
{
private:
	SQLHANDLE henv;
	SQLRETURN env_code;

public:
	Environment();
	~Environment();

	SQLRETURN envPass();
	SQLHANDLE getEnv();
};

#endif