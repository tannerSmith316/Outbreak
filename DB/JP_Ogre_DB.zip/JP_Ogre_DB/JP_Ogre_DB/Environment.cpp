#include "Environment.h"

Environment::Environment()
{
	SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	env_code = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER*)SQL_OV_ODBC3, 0);
}

Environment::~Environment()
{
	SQLFreeHandle(SQL_NULL_HANDLE, henv);
}

SQLRETURN Environment::envPass()
{
	return env_code;
}

SQLHANDLE Environment::getEnv()
{
	return henv;
}