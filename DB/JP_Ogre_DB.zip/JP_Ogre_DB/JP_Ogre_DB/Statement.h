#ifndef _STATEMENT_H
#define _STATEMENT_H

#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <iostream>

class Statement
{
private:
	SQLHANDLE hstmt;
	SQLRETURN stmt_code;
	SDWORD cbQual;
	char table_data[100];
	char f_name[100];
	char l_name[100];
	SQLUSMALLINT direction;

public:
	//ctor/dtor
	Statement();
	~Statement();

	SQLRETURN stmtPass();
	SQLHANDLE getStmt();

	void Interact(SQLHANDLE connect_hdbc, char* query, int columns);

	//columnbound
	void Insert(char* query);
	void makeQuery_Single(char* query);
	void makeQuery_Multiple(char* query);
};

#endif