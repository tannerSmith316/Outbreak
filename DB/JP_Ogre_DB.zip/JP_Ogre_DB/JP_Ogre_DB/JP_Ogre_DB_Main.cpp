#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <iostream>
#include "Statement.h"
#include "Connection.h"

using std::cin;
using std::cout;
using std::endl;

int menu();
void Create_New_Player(Connection con, Statement stmt);

int main()
{
	int menu_option(0);
	Connection connect;
	Statement stmt;

	while (menu_option != -1)
	{
		menu_option = menu();
		system ("cls");

		switch(menu_option)
		{
		case 1:
			Create_New_Player(connect, stmt);
			break;

		case 2:
			menu_option = -1;
			break;

		default:
			cout << "Not an option" << endl;
		}
	}

	return 0;
}

int menu()
{
	int option(0);

	cout << "Welcome to the C++ portion of OGRE POKE!" << endl;
	cout << "What would you like to do?" << endl;
	cout << "----------------------------------------" << endl;
	cout << "1) Create a player" << endl;
	cout << "2) Exit" << endl;
	cout << "--> ";
	cin >> option;
	cout << endl;

	return option;
}

void Create_New_Player(Connection con, Statement stmt)
{
	char name [20];
	double Latitude;
	double Longitude;
	char query_string[1000];

	cout << "What is your name?" << endl;
	cin >> name;

	cout << "What is your LATITUDE?" << endl;
	cin >> Latitude;

	cout << "What is your LONGITUDE?" << endl;
	cin >> Longitude;

	sprintf((char *)query_string, "insert into player values(playerid_seq.NEXTVAL, %f, %f, '%s')", Latitude, Longitude, name);

	stmt.Interact(con.get_hdbc(), query_string, 0);
	


}

	