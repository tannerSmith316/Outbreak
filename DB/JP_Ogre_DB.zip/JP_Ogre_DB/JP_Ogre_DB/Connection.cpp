#include "Connection.h"

Connection::Connection()
{
retcode = env.envPass();

HWND desktopHandle = GetDesktopWindow();		//desktop handle
sprintf((char *)InConnStr, "driver={Microsoft ODBC for Oracle};Server=CST324;uid=fauverk;pwd=fauverk", driver);  //connection string

if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) 
	{
		retcode = env.envPass(); 

		if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) 
			{
				retcode = SQLAllocHandle(SQL_HANDLE_DBC, env.getEnv(), &hdbc); 

				if (retcode == SQL_SUCCESS || retcode == SQL_SUCCESS_WITH_INFO) 
					{
						SQLSetConnectAttr(hdbc, SQL_LOGIN_TIMEOUT, (SQLPOINTER)5, 0);

						retcode = SQLDriverConnect( hdbc, desktopHandle, InConnStr, strlen((char*)InConnStr), OutConnStr, 255, &OutConnStrLen, SQL_DRIVER_NOPROMPT);
					}
			}
	}
}

Connection::~Connection()
{
	SQLDisconnect(hdbc);
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
}

SQLHANDLE Connection::get_hdbc()
{
	return hdbc;
}