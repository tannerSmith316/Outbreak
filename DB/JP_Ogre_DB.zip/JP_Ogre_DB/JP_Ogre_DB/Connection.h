#ifndef _CONNECTION_H
#define _CONNECTION_H

#include <iostream>
#include "Environment.h"

using namespace std;

class Connection
{
private:
	//connection required members
	Environment env;

	SQLHANDLE hdbc;
	SQLRETURN retcode;
	SQLCHAR OutConnStr[255];
	SQLCHAR InConnStr[512];
	SQLSMALLINT OutConnStrLen;
	char driver[1000];

public:
	//ctor/dtor
	Connection();
	~Connection();

	SQLHANDLE get_hdbc();
};

#endif