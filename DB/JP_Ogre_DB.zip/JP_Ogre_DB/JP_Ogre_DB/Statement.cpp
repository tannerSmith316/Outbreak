#include "Statement.h"

using std::cout;
using std::endl;

Statement::Statement()
{}

Statement::~Statement()
{}

SQLRETURN Statement::stmtPass()
{
	return stmt_code;
}

SQLHANDLE Statement::getStmt()
{
	return hstmt;
}

void Statement::Interact(SQLHANDLE connect_hdbc, char* query, int columns)
{
	bool complete = false;
	stmt_code = SQLAllocHandle(SQL_HANDLE_STMT, connect_hdbc, &hstmt);

	if (stmt_code == SQL_SUCCESS || stmt_code == SQL_SUCCESS_WITH_INFO) 
		{               
			stmt_code = SQLExecDirect(hstmt, (unsigned char *)query, SQL_NTS);

			while (!complete)
			{
				if (columns == 0)	//if insert/delete/drop/alter statement
					Insert(query);
				else if (columns == 1)
					makeQuery_Single(query);
				else if (columns > 1)
					makeQuery_Multiple(query);
				else
					cout << "Invalid Input" << endl;

				complete = true;
			}
		}

			SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
}

void Statement::Insert(char* query)
{
	cout << "Statement completed" << endl;
	cout << "-------------------" << endl;
	cout << endl;
}

void Statement::makeQuery_Single(char* query)
{
	SQLBindCol(hstmt, 1, SQL_CHAR, table_data, 100, &cbQual);

	while(!SQLFetch(hstmt))
		cout << table_data << endl;
	cout << "-------------------" << endl;
	cout << endl;
}


void Statement::makeQuery_Multiple(char* query)
{
	SQLBindCol(hstmt, 1, SQL_CHAR, f_name, 100, &cbQual);
	SQLBindCol(hstmt, 2, SQL_CHAR, l_name, 100, &cbQual);

	while(!SQLFetch(hstmt))
		cout << f_name << ' ' << l_name << endl;

	cout << "-------------------" << endl;
	cout << endl;
}